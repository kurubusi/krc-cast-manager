<?php


class Krc_File_Uploader {
	
	public function __construct () {}
	
	
	public function initialize () {
		
	}
	
	
	public function include_admin_scripts_styles(){
		
		
	}
	
	
}

?>