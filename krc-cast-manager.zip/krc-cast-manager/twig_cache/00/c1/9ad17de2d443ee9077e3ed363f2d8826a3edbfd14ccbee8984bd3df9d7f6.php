<?php

/* cast_schedule.html */
class __TwigTemplate_00c19ad17de2d443ee9077e3ed363f2d8826a3edbfd14ccbee8984bd3df9d7f6 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<div class=\"wrap\">
\t<div class=\"icon32\" id=\"icon-edit\"><br></div>
\t<h1>スケジュール管理</h1>
\t<div class=\"h_box\">
\t\t<h2><input type=\"text\" id=\"datepicker\" name=\"krc_datepicker\" /><input type=\"hidden\" id=\"schedule_target_day\" name=\"schedule_target_day\" value=\"";
        // line 5
        echo twig_escape_filter($this->env, (isset($context["schedule_target_day"]) ? $context["schedule_target_day"] : null), "html", null, true);
        echo "\" />の出勤スケジュールを登録</h2>
\t\t<div class=\"schedule_button\">
\t\t\t<a href=\"javascript: void(0)\" id=\"rest-schedule\" class=\"button-primary\">定休日</a>　
\t\t\t<a href=\"javascript: void(0)\" id=\"save-schedule\" class=\"button-primary\">　スケジュールの決定　<?php __('決定', 'krc' ) ?></a>
\t\t</div>
\t\t
\t</div>
\t<div id=\"ajax-response\"></div>
\t
\t<div id=\"krc-schedule-out\" class=\"postbox \" >
\t\t<h3 class='hndle'><span>出勤キャストBOX</span></h3>
\t\t<div class=\"inside\">
\t\t\t
\t\t\t<div id=\"schedule_cast_in\" class=\"cast_box\">
\t\t\t</div>
\t\t\t
\t\t\t<p class=\"krc_memo\">スケジュールの変更後は「スケジュールの決定」ボタンをクリックして下さい。<br>定休日に指定する場合はカレンダーで日付を選択して「定休日」ボタンをクリックして下さい。</p>
\t\t</div>
\t</div>
\t
\t<div id=\"krc-schedule-in\" class=\"postbox \" >
\t\t<h3 class='hndle'><span>欠勤キャストBOX</span></h3>
\t\t<div class=\"inside\">
\t\t\t
\t\t\t<div id=\"schedule_cast_out\" class=\"cast_box\">
\t\t\t</div>
\t\t\t
\t\t</div>
\t</div>
\t<div class=\"clear\"></div>
\t

\t
\t
</div>";
    }

    public function getTemplateName()
    {
        return "cast_schedule.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 5,  19 => 1,);
    }
}
