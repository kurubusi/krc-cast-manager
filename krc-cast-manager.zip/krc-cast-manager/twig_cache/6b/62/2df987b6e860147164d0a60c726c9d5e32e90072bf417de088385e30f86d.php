<?php

/* cast_meta.html */
class __TwigTemplate_6b622df987b6e860147164d0a60c726c9d5e32e90072bf417de088385e30f86d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<input type=\"hidden\" name=\"cast_meta_nonce\" value=\"";
        echo twig_escape_filter($this->env, (isset($context["cast_meta_nonce"]) ? $context["cast_meta_nonce"] : null), "html", null, true);
        echo "\" />
<table class=\"form-table\">
\t<tr>
\t\t<th style=''><label for='名前'>名前 *</label></th>
\t\t<td><input class='widefat' name='krc_name' id='krc_name' type='text' value='";
        // line 5
        echo twig_escape_filter($this->env, (isset($context["krc_name"]) ? $context["krc_name"] : null), "html", null, true);
        echo "' /></td>
\t</tr>
\t<tr>
\t\t<th style=''><label for='年齢'>年齢</label></th>
\t\t<td><select class='widefat' name=\"krc_age\" id=\"krc_age\">
\t\t\t<option ";
        // line 10
        if (((isset($context["krc_age"]) ? $context["krc_age"] : null) == 0)) {
            echo "selected";
        }
        echo " value=\"0\">未選択</option>
\t\t\t";
        // line 11
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable(range(18, 60));
        foreach ($context['_seq'] as $context["_key"] => $context["i"]) {
            // line 12
            echo "\t\t\t\t<option ";
            if (((isset($context["krc_age"]) ? $context["krc_age"] : null) == (isset($context["i"]) ? $context["i"] : null))) {
                echo "selected";
            }
            echo " value=\"";
            echo twig_escape_filter($this->env, (isset($context["i"]) ? $context["i"] : null), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, (isset($context["i"]) ? $context["i"] : null), "html", null, true);
            echo "</option>
\t\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['i'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 14
        echo "\t\t</select></td>\t</tr>
\t<tr>
\t\t<th style=''><label for='身長'>身長</label></th>
\t\t<td><select class='widefat' name=\"krc_tall\" id=\"krc_tall\">
\t\t\t<option ";
        // line 18
        if (((isset($context["krc_tall"]) ? $context["krc_tall"] : null) == 0)) {
            echo "selected";
        }
        echo " value=\"0\">未選択</option>
\t\t\t";
        // line 19
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable(range(130, 200));
        foreach ($context['_seq'] as $context["_key"] => $context["i"]) {
            // line 20
            echo "\t\t\t\t<option ";
            if (((isset($context["krc_tall"]) ? $context["krc_tall"] : null) == (isset($context["i"]) ? $context["i"] : null))) {
                echo "selected";
            }
            echo " value=\"";
            echo twig_escape_filter($this->env, (isset($context["i"]) ? $context["i"] : null), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, (isset($context["i"]) ? $context["i"] : null), "html", null, true);
            echo "</option>
\t\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['i'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 22
        echo "\t\t</select></td>
\t</tr>
\t<tr>
\t\t<th style=''><label for='バスト'>バスト</label></th>
\t\t<td><select class='widefat' name=\"krc_bust\" id=\"krc_bust\">
\t\t\t<option ";
        // line 27
        if (((isset($context["krc_bust"]) ? $context["krc_bust"] : null) == 0)) {
            echo "selected";
        }
        echo " value=\"0\">未選択</option>
\t\t\t";
        // line 28
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable(range(60, 140));
        foreach ($context['_seq'] as $context["_key"] => $context["i"]) {
            // line 29
            echo "\t\t\t\t<option ";
            if (((isset($context["krc_bust"]) ? $context["krc_bust"] : null) == (isset($context["i"]) ? $context["i"] : null))) {
                echo "selected";
            }
            echo " value=\"";
            echo twig_escape_filter($this->env, (isset($context["i"]) ? $context["i"] : null), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, (isset($context["i"]) ? $context["i"] : null), "html", null, true);
            echo "</option>
\t\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['i'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 31
        echo "\t\t</select></td>
\t</tr>
\t<tr>
\t\t<th style=''><label for='ウェスト'>ウェスト</label></th>
\t\t<td><select class='widefat' name=\"krc_waist\" id=\"krc_waist\">
\t\t\t<option ";
        // line 36
        if (((isset($context["krc_waist"]) ? $context["krc_waist"] : null) == 0)) {
            echo "selected";
        }
        echo " value=\"0\">未選択</option>
\t\t\t";
        // line 37
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable(range(45, 140));
        foreach ($context['_seq'] as $context["_key"] => $context["i"]) {
            // line 38
            echo "\t\t\t\t<option ";
            if (((isset($context["krc_waist"]) ? $context["krc_waist"] : null) == (isset($context["i"]) ? $context["i"] : null))) {
                echo "selected";
            }
            echo " value=\"";
            echo twig_escape_filter($this->env, (isset($context["i"]) ? $context["i"] : null), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, (isset($context["i"]) ? $context["i"] : null), "html", null, true);
            echo "</option>
\t\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['i'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 40
        echo "\t\t</select></td>
\t</tr>
\t<tr>
\t\t<th style=''><label for='ヒップ'>ヒップ</label></th>
\t\t<td><select class='widefat' name=\"krc_hips\" id=\"krc_hips\">
\t\t\t<option ";
        // line 45
        if (((isset($context["krc_hips"]) ? $context["krc_hips"] : null) == 0)) {
            echo "selected";
        }
        echo " value=\"0\">未選択</option>
\t\t\t";
        // line 46
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable(range(60, 140));
        foreach ($context['_seq'] as $context["_key"] => $context["i"]) {
            // line 47
            echo "\t\t\t\t<option ";
            if (((isset($context["krc_hips"]) ? $context["krc_hips"] : null) == (isset($context["i"]) ? $context["i"] : null))) {
                echo "selected";
            }
            echo " value=\"";
            echo twig_escape_filter($this->env, (isset($context["i"]) ? $context["i"] : null), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, (isset($context["i"]) ? $context["i"] : null), "html", null, true);
            echo "</option>
\t\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['i'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 49
        echo "\t\t</select></td>
\t</tr>
\t<tr>
\t\t<th style=''><label for='カップ'>カップ</label></th>
\t\t<td><select class='widefat' name=\"krc_cups\" id=\"krc_cups\">
\t\t\t<option ";
        // line 54
        if (((isset($context["krc_cups"]) ? $context["krc_cups"] : null) == 0)) {
            echo "selected";
        }
        echo " value=\"0\">未選択</option>
\t\t\t";
        // line 55
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable(range("A", "Z"));
        foreach ($context['_seq'] as $context["_key"] => $context["i"]) {
            // line 56
            echo "\t\t\t\t<option ";
            if (((isset($context["krc_cups"]) ? $context["krc_cups"] : null) == (isset($context["i"]) ? $context["i"] : null))) {
                echo "selected";
            }
            echo " value=\"";
            echo twig_escape_filter($this->env, (isset($context["i"]) ? $context["i"] : null), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, (isset($context["i"]) ? $context["i"] : null), "html", null, true);
            echo "</option>
\t\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['i'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 58
        echo "\t\t</select></td>
\t</tr>
\t
\t
\t
\t
\t
</table>
";
    }

    public function getTemplateName()
    {
        return "cast_meta.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  219 => 58,  204 => 56,  200 => 55,  194 => 54,  187 => 49,  172 => 47,  168 => 46,  162 => 45,  155 => 40,  140 => 38,  136 => 37,  130 => 36,  123 => 31,  108 => 29,  104 => 28,  98 => 27,  91 => 22,  76 => 20,  72 => 19,  66 => 18,  60 => 14,  45 => 12,  41 => 11,  35 => 10,  27 => 5,  19 => 1,);
    }
}
