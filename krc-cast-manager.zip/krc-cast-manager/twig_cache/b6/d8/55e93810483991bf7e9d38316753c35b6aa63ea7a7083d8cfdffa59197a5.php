<?php

/* ranking_in.html */
class __TwigTemplate_b6d855e93810483991bf7e9d38316753c35b6aa63ea7a7083d8cfdffa59197a5 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<input type=\"hidden\" name=\"ranking_in_meta_nonce\" value=\"";
        echo twig_escape_filter($this->env, (isset($context["ranking_in_meta_nonce"]) ? $context["ranking_in_meta_nonce"] : null), "html", null, true);
        echo "\" />
<div id=\"ranking_cast_in\" class=\"cast_box\">
\t
\t";
        // line 4
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["krc_cast_in_arr"]) ? $context["krc_cast_in_arr"] : null));
        foreach ($context['_seq'] as $context["id"] => $context["data"]) {
            // line 5
            echo "\t\t<dl class=\"ranking_cast\" id=\"";
            echo twig_escape_filter($this->env, (isset($context["id"]) ? $context["id"] : null), "html", null, true);
            echo "\">
\t\t\t<dt>";
            // line 6
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["data"]) ? $context["data"] : null), "krc_name", array()), "html", null, true);
            echo "</dt>
\t\t\t<dd><img src=\"";
            // line 7
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["data"]) ? $context["data"] : null), "krc_cast_screens", array()), "html", null, true);
            echo "\" width=\"100\" class=\"cast_photo\" /></dd>
\t\t\t<input type=\"hidden\" name=\"h_krc_cast_rankings[]\" class=\"krc_ranking_img_prev_hidden\" value=\"";
            // line 8
            echo twig_escape_filter($this->env, (isset($context["id"]) ? $context["id"] : null), "html", null, true);
            echo "\" />
\t\t</dl>
\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['id'], $context['data'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 11
        echo "\t
</div>
";
    }

    public function getTemplateName()
    {
        return "ranking_in.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  52 => 11,  43 => 8,  39 => 7,  35 => 6,  30 => 5,  26 => 4,  19 => 1,);
    }
}
