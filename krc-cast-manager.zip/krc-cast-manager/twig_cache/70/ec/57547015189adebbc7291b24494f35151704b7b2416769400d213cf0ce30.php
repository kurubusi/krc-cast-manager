<?php

/* ranking_meta.html */
class __TwigTemplate_70ec57547015189adebbc7291b24494f35151704b7b2416769400d213cf0ce30 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<input type=\"hidden\" name=\"ranking_meta_nonce\" value=\"";
        echo twig_escape_filter($this->env, (isset($context["ranking_meta_nonce"]) ? $context["ranking_meta_nonce"] : null), "html", null, true);
        echo "\" />
<table class=\"form-table\">
\t<tr>
\t\t<th style=''><label for='ランキングタイトル'>ランキングタイトル</label></th>
\t\t<td><input class='widefat' name='krc_ranking_title' id='krc_ranking_title' type='text' value='";
        // line 5
        echo twig_escape_filter($this->env, (isset($context["krc_ranking_title"]) ? $context["krc_ranking_title"] : null), "html", null, true);
        echo "' /></td>
\t</tr>
\t
\t
</table>
";
    }

    public function getTemplateName()
    {
        return "ranking_meta.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  27 => 5,  19 => 1,);
    }
}
