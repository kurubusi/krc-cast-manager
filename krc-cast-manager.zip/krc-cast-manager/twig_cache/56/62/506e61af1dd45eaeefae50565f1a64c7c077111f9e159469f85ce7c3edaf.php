<?php

/* ranking_out.html */
class __TwigTemplate_5662506e61af1dd45eaeefae50565f1a64c7c077111f9e159469f85ce7c3edaf extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<input type=\"hidden\" name=\"ranking_out_meta_nonce\" value=\"";
        echo twig_escape_filter($this->env, (isset($context["ranking_out_meta_nonce"]) ? $context["ranking_out_meta_nonce"] : null), "html", null, true);
        echo "\" />
<div id=\"ranking_cast_out\" class=\"cast_box\">
\t";
        // line 3
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["krc_cast_out_arr"]) ? $context["krc_cast_out_arr"] : null));
        foreach ($context['_seq'] as $context["id"] => $context["data"]) {
            // line 4
            echo "\t\t<dl class=\"ranking_cast\" id=\"";
            echo twig_escape_filter($this->env, (isset($context["id"]) ? $context["id"] : null), "html", null, true);
            echo "\">
\t\t\t<dt>";
            // line 5
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["data"]) ? $context["data"] : null), "krc_name", array()), "html", null, true);
            echo "</dt>
\t\t\t<dd><img src=\"";
            // line 6
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["data"]) ? $context["data"] : null), "krc_cast_screens", array()), "html", null, true);
            echo "\" width=\"100\" class=\"cast_photo\" /></dd>
\t\t</dl>
\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['id'], $context['data'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 9
        echo "</div>
";
    }

    public function getTemplateName()
    {
        return "ranking_out.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  47 => 9,  38 => 6,  34 => 5,  29 => 4,  25 => 3,  19 => 1,);
    }
}
