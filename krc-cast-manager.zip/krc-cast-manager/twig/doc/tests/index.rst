Tests
=====

.. toctree::
    :maxdepth: 1

    constant
    defined
    divisibleby
    empty
    even
    iterable
    null
    odd
    sameas
